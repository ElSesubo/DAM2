package es.florida.psp_ae1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class LanzadoraGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_jamon;
	private JTextField textField_pollo;
	private JTextField textField_bacalao;
	private JTextField textField_queso;
	private JTextArea textArea_salida;

	/**
	 * Método principal de la clase Lanzadora con interfaz gráfica
	 * 
	 * @param args No requiere parámetros de entrada
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LanzadoraGUI frame = new LanzadoraGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Método que crea la interfaz gráfica de la clase Lanzadora y define las acciones realizadas al hacer clic en el botón Lanzar
	 */
	public LanzadoraGUI() {
		setTitle("Lanzadora");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 825, 578);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("FÁBRICA DE CROQUETAS S.A.");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(24, 20, 764, 26);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("SOLICITUD DE PEDIDO");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(24, 73, 195, 17);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("TIPO");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(75, 121, 111, 17);
		contentPane.add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("PRIORIDAD");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_1.setBounds(177, 121, 111, 17);
		contentPane.add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("NÚMERO");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_1_1.setBounds(317, 121, 73, 17);
		contentPane.add(lblNewLabel_1_1_1_1);

		JLabel lblNewLabel_1_1_2 = new JLabel("Jamón");
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_2.setBounds(75, 157, 88, 17);
		contentPane.add(lblNewLabel_1_1_2);

		JLabel lblNewLabel_1_1_2_1 = new JLabel("Pollo");
		lblNewLabel_1_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_2_1.setBounds(75, 182, 88, 17);
		contentPane.add(lblNewLabel_1_1_2_1);

		JLabel lblNewLabel_1_1_2_1_1 = new JLabel("Bacalao");
		lblNewLabel_1_1_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_2_1_1.setBounds(75, 209, 88, 17);
		contentPane.add(lblNewLabel_1_1_2_1_1);

		JLabel lblNewLabel_1_1_2_1_1_1 = new JLabel("Queso");
		lblNewLabel_1_1_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_2_1_1_1.setBounds(75, 236, 88, 17);
		contentPane.add(lblNewLabel_1_1_2_1_1_1);

		JComboBox<String> comboBox_prioridadJamon = new JComboBox<String>();
		comboBox_prioridadJamon.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_prioridadJamon.setModel(new DefaultComboBoxModel<String>(new String[] { "1", "2", "3", "4" }));
		comboBox_prioridadJamon.setBounds(204, 157, 40, 21);
		contentPane.add(comboBox_prioridadJamon);

		JComboBox<String> comboBox_prioridadPollo = new JComboBox<String>();
		comboBox_prioridadPollo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_prioridadPollo.setModel(new DefaultComboBoxModel<String>(new String[] { "2", "1", "3", "4" }));
		comboBox_prioridadPollo.setBounds(204, 182, 40, 21);
		contentPane.add(comboBox_prioridadPollo);

		JComboBox<String> comboBox_prioridadBacalao = new JComboBox<String>();
		comboBox_prioridadBacalao.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_prioridadBacalao.setModel(new DefaultComboBoxModel<String>(new String[] { "3", "1", "2", "4" }));
		comboBox_prioridadBacalao.setBounds(204, 209, 40, 21);
		contentPane.add(comboBox_prioridadBacalao);

		JComboBox<String> comboBox_prioridadQueso = new JComboBox<String>();
		comboBox_prioridadQueso.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_prioridadQueso.setModel(new DefaultComboBoxModel<String>(new String[] { "4", "1", "2", "3" }));
		comboBox_prioridadQueso.setBounds(204, 236, 40, 21);
		contentPane.add(comboBox_prioridadQueso);

		textField_jamon = new JTextField();
		textField_jamon.setText("0");
		textField_jamon.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_jamon.setBounds(317, 158, 64, 19);
		contentPane.add(textField_jamon);
		textField_jamon.setColumns(10);

		textField_pollo = new JTextField();
		textField_pollo.setText("0");
		textField_pollo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_pollo.setColumns(10);
		textField_pollo.setBounds(317, 183, 64, 19);
		contentPane.add(textField_pollo);

		textField_bacalao = new JTextField();
		textField_bacalao.setText("0");
		textField_bacalao.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_bacalao.setColumns(10);
		textField_bacalao.setBounds(317, 210, 64, 19);
		contentPane.add(textField_bacalao);

		textField_queso = new JTextField();
		textField_queso.setText("0");
		textField_queso.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_queso.setColumns(10);
		textField_queso.setBounds(317, 237, 64, 19);
		contentPane.add(textField_queso);

		JButton btn_lanzar = new JButton("Lanzar");
		btn_lanzar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean comprobacionNumero = true;
				int numeroJamon = Integer.parseInt(textField_jamon.getText());
				if (numeroJamon % 6 != 0)
					comprobacionNumero = false;

				int numeroPollo = Integer.parseInt(textField_pollo.getText());
				if (numeroPollo % 6 != 0)
					comprobacionNumero = false;

				int numeroBacalao = Integer.parseInt(textField_bacalao.getText());
				if (numeroBacalao % 6 != 0)
					comprobacionNumero = false;

				int numeroQueso = Integer.parseInt(textField_queso.getText());
				if (numeroQueso % 6 != 0)
					comprobacionNumero = false;

				if (comprobacionNumero) {

					int prioridadJamon = Integer.parseInt((String) comboBox_prioridadJamon.getSelectedItem());
					int prioridadPollo = Integer.parseInt((String) comboBox_prioridadPollo.getSelectedItem());
					int prioridadBacalao = Integer.parseInt((String) comboBox_prioridadBacalao.getSelectedItem());
					int prioridadQueso = Integer.parseInt((String) comboBox_prioridadQueso.getSelectedItem());

					String tipo1 = "", tipo2 = "", tipo3 = "", tipo4 = "";
					int num1 = 0, num2 = 0, num3 = 0, num4 = 0;
					switch (prioridadJamon) {
					case 1:
						tipo1 = "Jamon";
						num1 = numeroJamon;
						break;
					case 2:
						tipo2 = "Jamon";
						num2 = numeroJamon;
						break;
					case 3:
						tipo3 = "Jamon";
						num3 = numeroJamon;
						break;
					case 4:
						tipo4 = "Jamon";
						num4 = numeroJamon;
						break;
					default:
						tipo1 = "Jamon";
						num1 = numeroJamon;
						break;
					}
					switch (prioridadPollo) {
					case 1:
						tipo1 = "Pollo";
						num1 = numeroPollo;
						break;
					case 2:
						tipo2 = "Pollo";
						num2 = numeroPollo;
						break;
					case 3:
						tipo3 = "Pollo";
						num3 = numeroPollo;
						break;
					case 4:
						tipo4 = "Pollo";
						num4 = numeroPollo;
						break;
					default:
						tipo1 = "Pollo";
						num1 = numeroPollo;
						break;
					}
					switch (prioridadBacalao) {
					case 1:
						tipo1 = "Bacalao";
						num1 = numeroBacalao;
						break;
					case 2:
						tipo2 = "Bacalao";
						num2 = numeroBacalao;
						break;
					case 3:
						tipo3 = "Bacalao";
						num3 = numeroBacalao;
						break;
					case 4:
						tipo4 = "Bacalao";
						num4 = numeroBacalao;
						break;
					default:
						tipo1 = "Bacalao";
						num1 = numeroBacalao;
						break;
					}
					switch (prioridadQueso) {
					case 1:
						tipo1 = "Queso";
						num1 = numeroQueso;
						break;
					case 2:
						tipo2 = "Queso";
						num2 = numeroQueso;
						break;
					case 3:
						tipo3 = "Queso";
						num3 = numeroQueso;
						break;
					case 4:
						tipo4 = "Queso";
						num4 = numeroQueso;
						break;
					default:
						tipo1 = "Queso";
						num1 = numeroQueso;
						break;
					}
					llamadaProcesadora(tipo1, num1, tipo2, num2, tipo3, num3, tipo4, num4);
				} else {
					JOptionPane.showMessageDialog(null, "Comprobar que las unidades especificadas sean múltiplos de 6.",
							"ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}

		});
		btn_lanzar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn_lanzar.setBounds(446, 236, 85, 21);
		contentPane.add(btn_lanzar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 282, 753, 249);
		contentPane.add(scrollPane);

		textArea_salida = new JTextArea();
		scrollPane.setViewportView(textArea_salida);
	}

	/**
	 * Método que llama a la aplicación Procesadora y crea los hilos-gestores para sus salidas (normal y error) 
	 * 
	 * @param tipo1 String con el tipo de croqueta a fabricar en primer lugar.
	 * @param num1 Entero con el número de croquetas a fabricar de tipo 1.
	 * @param tipo2 String con el tipo de croqueta a fabricar en segundo lugar.
	 * @param num2 Entero con el número de croquetas a fabricar de tipo 2.
	 * @param tipo3 String con el tipo de croqueta a fabricar en tercer lugar.
	 * @param num3 Entero con el número de croquetas a fabricar de tipo 3.
	 * @param tipo4 String con el tipo de croqueta a fabricar en cuarto lugar.
	 * @param num4 Entero con el número de croquetas a fabricar de tipo 4.
	 */
	public void llamadaProcesadora(String tipo1, int num1, String tipo2, int num2, String tipo3, int num3, String tipo4,
			int num4) {

		try {
			String clase = "es.florida.psp_ae1.Procesadora";
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(tipo1);
			command.add(String.valueOf(num1));
			command.add(tipo2);
			command.add(String.valueOf(num2));
			command.add(tipo3);
			command.add(String.valueOf(num3));
			command.add(tipo4);
			command.add(String.valueOf(num4));

			long tiempoInicio = System.nanoTime();
			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.start();
			
			BufferedReader inputStream = new BufferedReader(new InputStreamReader(process.getInputStream()));
			BufferedReader errorStream = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			CustomOutputStream salidaNormal = new CustomOutputStream(inputStream, false, textArea_salida);
			CustomOutputStream salidaError = new CustomOutputStream(errorStream, true, textArea_salida);
			Thread hiloNormal = new Thread(salidaNormal);
			Thread hiloError = new Thread(salidaError);
			hiloNormal.start();
			hiloError.start();
			
			process.waitFor();
			
			inputStream.close();
			errorStream.close();
			
			long tiempoFin = System.nanoTime();
			long duracion = (tiempoFin - tiempoInicio) / 1000000; // milisegundos
			JOptionPane.showMessageDialog(null, "Tiempo ejecucion total: " + duracion + " ms", "PROCESO FINALIZADO",
					JOptionPane.INFORMATION_MESSAGE);

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

}
