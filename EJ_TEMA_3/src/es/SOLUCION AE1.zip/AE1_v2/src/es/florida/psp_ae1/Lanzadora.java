package es.florida.psp_ae1;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Lanzadora {

	/**
	 * Método que realiza la llamada a la clase ejecutable Procesadora con las instrucciones del pedido a fabricar.
	 * @param tipo1 String con el tipo de croqueta a fabricar en primer lugar.
	 * @param num1 Entero con el número de croquetas a fabricar de tipo 1.
	 * @param tipo2 String con el tipo de croqueta a fabricar en segundo lugar.
	 * @param num2 Entero con el número de croquetas a fabricar de tipo 2.
	 * @param tipo3 String con el tipo de croqueta a fabricar en tercer lugar.
	 * @param num3 Entero con el número de croquetas a fabricar de tipo 3.
	 * @param tipo4 String con el tipo de croqueta a fabricar en cuarto lugar.
	 * @param num4 Entero con el número de croquetas a fabricar de tipo 4.
	 */
	public static void llamadaProcesadora(String tipo1, int num1, String tipo2, int num2, String tipo3, int num3, String tipo4, int num4) {

		try {
			String clase = "es.florida.psp_ae1.Procesadora";
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(tipo1);
			command.add(String.valueOf(num1));
			command.add(tipo2);
			command.add(String.valueOf(num2));
			command.add(tipo3);
			command.add(String.valueOf(num3));
			command.add(tipo4);
			command.add(String.valueOf(num4));

			long tiempoInicio = System.nanoTime();
			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.inheritIO().start();
			process.waitFor();
			long tiempoFin = System.nanoTime();
			long duracion = (tiempoFin - tiempoInicio)/1000000;  //milisegundos
			System.out.println("\nFIN - Tiempo ejecucion total: " + duracion + " ms");
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
		}

	}

	/**
	 * Clase principal de la aplicacion Lanzadora.
	 * @param args No se requieren argumentos de entrada.
	 */
	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		String[] tipos = new String[] { "Jamon", "Pollo", "Bacalao", "Queso" };
		System.out.println("FABRICA DE CROQUETAS S.A. - Solicitud de pedido a fabrica");
		System.out.println("Tipos disponibles: Jamon - Pollo - Bacalao - Queso");
		System.out.print("Indicar prioridad 1 (1)Jamon (2)Pollo (3)Bacalao (4)Queso: ");
		String tipo1 = tipos[Integer.parseInt(teclado.nextLine())-1];
		System.out.print("Indicar prioridad 2 (1)Jamon (2)Pollo (3)Bacalao (4)Queso: ");
		String tipo2= tipos[Integer.parseInt(teclado.nextLine())-1];
		System.out.print("Indicar prioridad 3 (1)Jamon (2)Pollo (3)Bacalao (4)Queso: ");
		String tipo3 = tipos[Integer.parseInt(teclado.nextLine())-1];
		System.out.print("Indicar prioridad 4 (1)Jamon (2)Pollo (3)Bacalao (4)Queso: ");
		String tipo4 = tipos[Integer.parseInt(teclado.nextLine())-1];
		System.out.print("Indicar numero de croquetas de " + tipo1 + ": ");
		int num1 = Integer.parseInt(teclado.nextLine());
		while (num1 % 6 != 0) {
			System.out.print("Indicar un numero multiple de 6: ");
			num1 = Integer.parseInt(teclado.nextLine());
		}
		System.out.print("Indicar numero de croquetas de " + tipo2 + ": ");
		int num2 = Integer.parseInt(teclado.nextLine());
		while (num2 % 6 != 0) {
			System.out.print("Indicar un numero multiple de 6: ");
			num2 = Integer.parseInt(teclado.nextLine());
		}
		System.out.print("Indicar numero de croquetas de " + tipo3 + ": ");
		int num3 = Integer.parseInt(teclado.nextLine());
		while (num3 % 6 != 0) {
			System.out.print("Indicar un numero multiple de 6: ");
			num3 = Integer.parseInt(teclado.nextLine());
		}
		System.out.print("Indicar numero de croquetas de " + tipo4 + ": ");
		int num4 = Integer.parseInt(teclado.nextLine());
		while (num4 % 6 != 0) {
			System.out.print("Indicar un numero multiple de 6: ");
			num4 = Integer.parseInt(teclado.nextLine());
		}
		llamadaProcesadora(tipo1, num1, tipo2, num2, tipo3, num3, tipo4, num4);

	}

}
