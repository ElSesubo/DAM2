package es.florida.psp_ae1;

import java.io.BufferedReader;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class CustomOutputStream implements Runnable {
    private BufferedReader buffer;
    private boolean error;
	private JTextArea textArea;
     
    /**
     * Método constructor para la clase-hilo que gestiona las salidas de la aplicación Procesadora para mostrarlas por pantalla, según sea normal o error y las guarde también en el textArea
     * 
     * @param buffer BufferedReader de salida de la Procesadora (normal o error)
     * @param error Boolean que indica si se trata de salida de tipo error (true) o normal (false)
     * @param textArea JTextArea con la variable que apunta al textArea de la interfaz
     */
    public CustomOutputStream(BufferedReader buffer, boolean error, JTextArea textArea) {
    	this.buffer = buffer;
    	this.error = error;
        this.textArea = textArea;
    }
     

	/**
	 * Método run del hilo gestor de salidas de la clase Procesadora que muestra por pantalla la salida (normal o error) y la añade también al textArea
	 */
	@Override
	public void run() {
		try {
			String output;
			while ((output = buffer.readLine()) != null) {
				if (error)
					System.err.println(output);
				else
					System.out.println(output);
		        textArea.append(output + "\n");
		        // Scroll hasta el final
		        textArea.setCaretPosition(textArea.getDocument().getLength());			
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}
}