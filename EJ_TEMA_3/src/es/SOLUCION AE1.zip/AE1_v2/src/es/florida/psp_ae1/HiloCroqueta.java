package es.florida.psp_ae1;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class HiloCroqueta implements Runnable {

	static int numHilos;
	String tipo;
	ArrayList<String> listaPedido;
	int[] tiemposCroqueta = { 5000, 6000, 7000, 8000 }; // Jamon, Pollo, Bacalao, Queso

	/**
	 * Método constructor de la clase HiloCroqueta.
	 * @param tipo String con el tipo de croqueta a fabricar.
	 * @param listaPedido ArrayList de Strings con la lista de croquetas fabricadas.
	 */
	HiloCroqueta(String tipo, ArrayList<String> listaPedido) {
		this.tipo = tipo;
		this.listaPedido = listaPedido;
	}

	/**
	 * Método run del hilo que simula la fabricación de una croqueta con un tiempo asignado en función del tipo.
	 */
	@Override
	public void run() {

		numHilos++;
		try {
			switch (tipo) {
				case "Jamon":
					Thread.sleep(tiemposCroqueta[0]);
					break;
				case "Pollo":
					Thread.sleep(tiemposCroqueta[1]);
					break;
				case "Bacalao":
					Thread.sleep(tiemposCroqueta[2]);
					break;
				case "Queso":
					Thread.sleep(tiemposCroqueta[3]);
					break;
				default:
					break;
			}

		} catch (InterruptedException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
		}
		synchronized (listaPedido) {
			listaPedido.add(tipo);
			System.out.println(
					Thread.currentThread().getName() + ">>> Croqueta de tipo " + tipo + " anyadida al pedido.");
		}
		numHilos--;

	}

}
