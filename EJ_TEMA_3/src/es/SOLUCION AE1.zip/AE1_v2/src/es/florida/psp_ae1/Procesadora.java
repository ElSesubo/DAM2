package es.florida.psp_ae1;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Procesadora {

	/**
	 * Clase principal de la aplicación Procesadora, que recibe un pedido por argumentos y lanza los hilos para la fabricación de croquetas.
	 * @param args String con el tipo de croquetas a fabricar en primer lugar, entero con el número de croquetas de dicho tipo, String para tipo 2, entero para tipo 2, String para tipo 3, entero para tipo 3, String para tipo 4, entero para tipo 4.
	 */
	public static void main(String[] args) {

		String tipo1 = args[0];
		int num1 = Integer.parseInt(args[1]);
		String tipo2 = args[2];
		int num2 = Integer.parseInt(args[3]);
		String tipo3 = args[4];
		int num3 = Integer.parseInt(args[5]);
		String tipo4 = args[6];
		int num4 = Integer.parseInt(args[7]);
		int total = num1 + num2 + num3 + num4;
		int capacidad = 100;
		ArrayList<String> tipos = new ArrayList<String>();
		for (int i = 0; i < num1; i++) tipos.add(tipo1);
		for (int i = 0; i < num2; i++) tipos.add(tipo2);
		for (int i = 0; i < num3; i++) tipos.add(tipo3);
		for (int i = 0; i < num4; i++) tipos.add(tipo4);
		
		ArrayList<String> listaPedido = new ArrayList<String>();
		for (int i = 0; i < total; i++) {
			System.out.println("Croquetas en proceso " + HiloCroqueta.numHilos);
			while (HiloCroqueta.numHilos >= capacidad) {
				try {
					System.err.println(">>>>>>>>>>>>>>>>>>>> La procesadora ha alcanzado su capacidad maxima. Comprobacion en 3 segundos <<<<<<<<<<<<<<<<<<<<");
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
			HiloCroqueta hc = new HiloCroqueta(tipos.get(i), listaPedido);
			Thread hilo = new Thread(hc);
			hilo.start();
			System.out.println("Inicio de fabricacion de croqueta de " + tipos.get(i) + " (" + hilo.getName() + ")");
		}
		while (listaPedido.size() < total) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),	"ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
		System.out.println("\nNUMERO DE CROQUETAS PROCESADAS: " + listaPedido.size());

	}

}
